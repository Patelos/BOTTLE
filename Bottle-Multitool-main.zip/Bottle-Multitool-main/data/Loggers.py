
print("""
Here are some good ip loggers
1. https://grabify.link/
2. https://iplogger.org/
3. soon..""")
input("click enter to close")
exit()