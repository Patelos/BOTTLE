<p align="center">
 
![Screenshot_4](https://github.com/eggy22/Bottle-Multitool/assets/106061655/6590ecbf-b883-483d-934f-98303eb9d66e)





A powerful Multitool made with python<br/>


## Installing
 

```
Just open the setup.bat
```

## Main features

* UrlFlooder
* Webhook Spammer
* Nuker
* IP Address Lookup
* IP Pinger
* IP Loggers
* Screenshot Grabber
* WebHook Remover
* Linkvertise bypasser
* View wifi pass
* pass gen
* fake info gen
* url shorten
* qr code gen
 
If there is any error dm eggy#8081 on discord 
Thanks for using my tool:)


## Screenshot
![Screenshot_1](https://github.com/eggy22/Bottle-Multitool/assets/106061655/80dcc1c8-4d83-4bb9-8ced-eb6b96203c38)



Please note that the infos and information contained in this program is for educational purposes only and should not be used to unauthorized / illegal activities. The developer and contributors are not responsible for any misuse of this software.

